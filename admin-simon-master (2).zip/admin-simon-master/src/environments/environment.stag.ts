export const environment  = {
     production: true,
     environmentName: 'Staging',
     apiUrl: 'https://tutorbackend.herokuapp.com/api/v1'  
}